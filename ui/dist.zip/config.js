// 系统名称
window.appTitle = "宏之博教务系统"
// 后端接口地址 生产环境下不要使用localhost，应该把localhost:8106 改成你自己的域名或ip：
// window.appBaseUrl = "http://localhost:8106/app"
// 如果后端和前端使用一样的域名，可以使用下面这样配置：
window.appBaseUrl = window.location.protocol +'//'+window.location.host + '/app';
// 系统logo
window.appLogo = "http://hzb-it.com/logo.png"
// 是否是演示版
window.isDemo = false