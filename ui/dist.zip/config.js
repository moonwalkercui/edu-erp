// 后端接口地址
window.appBaseUrl = "http://localhost:8106/app"
// 系统名称
window.appTitle = "宏之博教务系统"
// 系统副标题
window.appSubject = "教培行业云化解决方案"
// 系统logo
window.appLogo = "http://hzb-it.com/logo.png"
// 是否是演示版
window.isDemo = false